import React from "react";
import CountriesList from "../components/CountriesList";

function Home() {
  return (
    <div className="py-10">
      <CountriesList />
    </div>
  );
}

export default Home;
